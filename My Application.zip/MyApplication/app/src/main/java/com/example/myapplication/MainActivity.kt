// En: app/src/main/java/com/example/myapplication/MainActivity.kt

package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// --- MODELOS DE DATOS ---
data class Product(
    val id: Int,
    val name: String,
    val price: Double,
    val description: String,
    val category: String,
    val images: List<Int>,
    val availableSizes: List<String>,
    val availableColors: List<Color>,
    val stock: Int
)

data class User(
    val name: String,
    val email: String,
    val phone: String,
    val profileImageRes: Int
)

// --- DATOS DE EJEMPLO ---
object SampleData {
    // ... (la lista de productos se mantiene igual, la he omitido aquí por brevedad)
    val products = listOf(
        // --- Productos de Hombre ---
        Product(
            id = 1, name = "Camiseta Gráfica", price = 29.99, category = "Hombre",
            description = "Camiseta de algodón suave con un diseño gráfico moderno.",
            images = listOf(R.drawable.camisaazul),
            availableSizes = listOf("S", "M", "L", "XL"),
            availableColors = listOf(Color.Black, Color.White, Color.Gray), stock = 15
        ),
        Product(
            id = 2, name = "Pantalón Chino", price = 49.99, category = "Hombre",
            description = "Pantalón de corte slim fit, cómodo y con estilo.",
            images = listOf(R.drawable.pantalon),
            availableSizes = listOf("30", "32", "34", "36"),
            availableColors = listOf(Color(0xFF3D405B), Color(0xFF81B29A)), stock = 12
        ),
        Product(
            id = 7, name = "Chaqueta Vaquera", price = 79.99, category = "Hombre",
            description = "Un clásico atemporal, chaqueta vaquera de corte recto.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("M", "L", "XL"),
            availableColors = listOf(Color(0xFF1565C0)), stock = 8
        ),
        Product(
            id = 10, name = "Zapatos de Vestir", price = 119.99, category = "Hombre",
            description = "Zapatos de cuero elegantes para ocasiones formales.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("41", "42", "43", "44"),
            availableColors = listOf(Color.Black, Color(0xFF5D4037)), stock = 7
        ),
        Product(
            id = 11, name = "Polo Básico", price = 34.99, category = "Hombre",
            description = "Polo de piqué de algodón con cuello clásico de dos botones.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("S", "M", "L", "XL"),
            availableColors = listOf(Color.White, Color.Blue, Color.Red), stock = 22
        ),

        // --- Productos de Mujer ---
        Product(
            id = 3, name = "Zapatillas Urbanas", price = 89.99, category = "Mujer",
            description = "Zapatillas de estilo urbano con suela de goma resistente.",
            images = listOf(R.drawable.zapatillas),
            availableSizes = listOf("38", "39", "40", "41"),
            availableColors = listOf(Color.White, Color.Black, Color(0xFFF48FB1)), stock = 20
        ),
        Product(
            id = 5, name = "Sudadera con Capucha", price = 59.99, category = "Mujer",
            description = "Sudadera de felpa suave, ideal para el frío.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("S", "M", "L"),
            availableColors = listOf(Color.DarkGray, Color(0xFFE1BEE7)), stock = 10
        ),
        Product(
            id = 8, name = "Vestido Floral", price = 69.99, category = "Mujer",
            description = "Vestido ligero con estampado floral, perfecto para el verano.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("S", "M", "L"),
            availableColors = listOf(Color.Red, Color.Yellow, Color.Blue), stock = 14
        ),
        Product(
            id = 12, name = "Bolso de Hombro", price = 45.50, category = "Mujer",
            description = "Bolso elegante de cuero sintético con correa ajustable.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("Única"),
            availableColors = listOf(Color.Black, Color(0xFFD2B48C), Color.LightGray), stock = 11
        ),
        Product(
            id = 13, name = "Blusa de Seda", price = 55.00, category = "Mujer",
            description = "Blusa de seda con cuello en V y manga larga, ideal para la oficina.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("XS", "S", "M", "L"),
            availableColors = listOf(Color.White, Color(0xFFFFF8E1), Color.LightGray), stock = 15
        ),

        // --- Productos de Niño ---
        Product(
            id = 9, name = "Pijama de Dinosaurios", price = 25.99, category = "Niño",
            description = "Pijama de dos piezas divertido y cómodo para niños.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("4A", "6A", "8A"),
            availableColors = listOf(Color.Green, Color.Blue), stock = 18
        ),
        Product(
            id = 14, name = "Chubasquero Amarillo", price = 39.99, category = "Niño",
            description = "Chubasquero impermeable con capucha y forro interior de algodón.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("5A", "7A", "9A"),
            availableColors = listOf(Color.Yellow), stock = 20
        ),
        Product(
            id = 15, name = "Mochila Escolar", price = 22.99, category = "Niño",
            description = "Mochila resistente con múltiples compartimentos y diseño de cohete.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("Única"),
            availableColors = listOf(Color.Blue, Color.Red), stock = 25
        ),

        // --- Productos para Adulto (Unisex) ---
        Product(
            id = 4, name = "Gorra de Béisbol", price = 19.99, category = "Adulto",
            description = "Gorra clásica con logo bordado y cierre ajustable.",
            images = listOf(R.drawable.gorra),
            availableSizes = listOf("Única"),
            availableColors = listOf(Color.DarkGray, Color.Red, Color.Blue), stock = 30
        ),
        Product(
            id = 6, name = "Calcetines Deportivos", price = 9.99, category = "Adulto",
            description = "Pack de 3 pares de calcetines de algodón transpirable.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("39-42", "43-46"),
            availableColors = listOf(Color.White, Color.Black), stock = 50
        ),
        Product(
            id = 16, name = "Bufanda de Lana", price = 24.99, category = "Adulto",
            description = "Bufanda unisex, suave y cálida para el invierno.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("Única"),
            availableColors = listOf(Color.Gray, Color(0xFF3E2723), Color.Blue), stock = 25
        ),
        Product(
            id = 17, name = "Gafas de Sol", price = 129.99, category = "Adulto",
            description = "Gafas de sol con protección UV400 y montura de pasta.",
            images = listOf(R.drawable.ic_launcher_background), // Reemplaza con tu imagen
            availableSizes = listOf("Única"),
            availableColors = listOf(Color.Black), stock = 13
        )
    )
}

// Usuario de ejemplo
object CurrentUser {
    val user = User(
        name = "Elian Argueta", // <-- NOMBRE CAMBIADO
        email = "elian.argueta@example.com", // <-- EMAIL ACTUALIZADO
        phone = "+1 234 567 890",
        profileImageRes = R.drawable.elian // <-- IMAGEN CAMBIADA
    )
}

// Objeto para definir las rutas de navegación
object Routes {
    const val PRODUCT_LIST = "productList"
    const val PRODUCT_DETAIL = "productDetail/{productId}"
    const val CART = "cart"
    const val PROFILE = "profile" // Nueva ruta para el perfil
    fun getProductDetailPath(productId: Int) = "productDetail/$productId"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                EcommerceApp()
            }
        }
    }
}

// --- NAVEGACIÓN Y GESTIÓN DE ESTADO PRINCIPAL ---
@Composable
fun EcommerceApp() {
    val navController = rememberNavController()
    val cartItems = remember { mutableStateListOf<Product>() }
    val screensWithBottomBar = listOf(Routes.PRODUCT_LIST, Routes.CART, Routes.PROFILE)
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val showBottomBar = screensWithBottomBar.any { it == currentDestination?.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                AppBottomBar(navController = navController, cartItemCount = cartItems.size)
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.PRODUCT_LIST,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.PRODUCT_LIST) {
                ProductListScreen(
                    products = SampleData.products,
                    user = CurrentUser.user,
                    onProductClick = { productId ->
                        navController.navigate(Routes.getProductDetailPath(productId))
                    }
                )
            }
            composable(
                route = Routes.PRODUCT_DETAIL,
                arguments = listOf(navArgument("productId") { type = NavType.IntType })
            ) { backStackEntry ->
                val productId = backStackEntry.arguments?.getInt("productId")
                val product = SampleData.products.find { it.id == productId }
                if (product != null) {
                    ProductDetailScreen(
                        product = product,
                        onAddToCart = { selectedProduct ->
                            if (!cartItems.contains(selectedProduct)) {
                                cartItems.add(selectedProduct)
                            }
                        },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
            composable(Routes.CART) {
                CartScreen(
                    cartItems = cartItems,
                    onRemoveItem = { productToRemove ->
                        cartItems.remove(productToRemove)
                    }
                )
            }
            composable(Routes.PROFILE) {
                ProfileScreen(user = CurrentUser.user)
            }
        }
    }
}

// --- MENÚ DE NAVEGACIÓN INFERIOR ---
@Composable
fun AppBottomBar(navController: NavHostController, cartItemCount: Int) {
    val items = listOf(
        "Tienda" to Icons.Outlined.Home,
        "Carrito" to Icons.Outlined.ShoppingCart,
        "Perfil" to Icons.Outlined.Person
    )
    val routes = listOf(Routes.PRODUCT_LIST, Routes.CART, Routes.PROFILE)
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    NavigationBar {
        items.forEachIndexed { index, (label, icon) ->
            NavigationBarItem(
                icon = {
                    if (label == "Carrito" && cartItemCount > 0) {
                        BadgedBox(badge = { Badge { Text("$cartItemCount") } }) {
                            Icon(icon, contentDescription = label)
                        }
                    } else {
                        Icon(icon, contentDescription = label)
                    }
                },
                label = { Text(label) },
                selected = currentDestination?.hierarchy?.any { it.route == routes[index] } == true,
                onClick = {
                    navController.navigate(routes[index]) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

// --- PANTALLA DE LISTA DE PRODUCTOS ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductListScreen(
    products: List<Product>,
    user: User,
    onProductClick: (Int) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val categories = listOf("Todos", "Hombre", "Mujer", "Niño", "Adulto")
    var selectedCategory by remember { mutableStateOf("Todos") }

    val filteredProducts = products.filter { product ->
        val matchesCategory = selectedCategory == "Todos" || product.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() || product.name.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.background,
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.1f)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
    ) {
        // --- Barra superior con título e imagen de usuario ---
        TopAppBar(
            title = { Text("Mi Tienda", fontWeight = FontWeight.Bold) },
            actions = {
                Image(
                    painter = painterResource(id = user.profileImageRes),
                    contentDescription = "Imagen de perfil",
                    modifier = Modifier
                        .padding(end = 16.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                )
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Transparent // Fondo transparente para que se vea el gradiente
            )
        )

        SearchBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
        )

        CategoryRow(
            categories = categories,
            selectedCategory = selectedCategory,
            onCategorySelected = { selectedCategory = it },
            modifier = Modifier.padding(vertical = 12.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(filteredProducts, key = { it.id }) { product ->
                ProductGridItem(product = product, onProductClick = onProductClick)
            }
        }
    }
}

// --- BARRA DE BÚSQUEDA ---
// ... (Sin cambios)
@Composable
fun SearchBar(query: String, onQueryChange: (String) -> Unit, modifier: Modifier = Modifier) {
    TextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier.fillMaxWidth(),
        placeholder = { Text("Buscar productos...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Icono de búsqueda") },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Default.Close, contentDescription = "Limpiar búsqueda")
                }
            }
        },
        shape = RoundedCornerShape(32.dp),
        colors = TextFieldDefaults.colors(
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    )
}


// --- FILA DE CATEGORÍAS ---
// ... (Sin cambios)
@Composable
fun CategoryRow(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(categories) { category ->
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable { onCategorySelected(category) }
                    .background(
                        if (category == selectedCategory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .padding(vertical = 8.dp, horizontal = 20.dp)
            ) {
                Text(
                    text = category,
                    color = if (category == selectedCategory) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// --- ELEMENTO INDIVIDUAL EN LA CUADRÍCULA ---
// ... (Sin cambios)
@Composable
fun ProductGridItem(product: Product, onProductClick: (Int) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onProductClick(product.id) },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface) // Para mejor contraste
    ) {
        Column {
            Image(
                painter = painterResource(id = product.images.first()),
                contentDescription = product.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f),
                contentScale = ContentScale.Crop
            )
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$${String.format("%.2f", product.price)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}


// --- ELEMENTO INDIVIDUAL EN LA LISTA DEL CARRITO ---
// ... (Sin cambios)
@Composable
fun ProductCartItem(product: Product, onRemoveClick: (Product) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = product.images.first()),
                contentDescription = product.name,
                modifier = Modifier
                    .size(70.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$${String.format("%.2f", product.price)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = { onRemoveClick(product) }) {
                Icon(
                    imageVector = Icons.Outlined.Delete,
                    contentDescription = "Eliminar del carrito",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}


// --- PANTALLA DE DETALLE DEL PRODUCTO ---
// ... (Sin cambios, pero el @OptIn que tenías era incorrecto, lo he corregido)
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
    product: Product,
    onAddToCart: (Product) -> Unit,
    onBack: () -> Unit
) {
    var selectedSize by remember { mutableStateOf(product.availableSizes.firstOrNull()) }
    var selectedColor by remember { mutableStateOf(product.availableColors.firstOrNull()) }
    var showNotification by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(product.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    items(product.images) { imageRes ->
                        Image(
                            painter = painterResource(id = imageRes),
                            contentDescription = null,
                            modifier = Modifier.fillParentMaxWidth(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(product.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "$${String.format("%.2f", product.price)}",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Descripción", style = MaterialTheme.typography.titleMedium)
                    Text(product.description, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Talla", style = MaterialTheme.typography.titleMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        product.availableSizes.forEach { size ->
                            FilterChip(
                                selected = size == selectedSize,
                                onClick = { selectedSize = size },
                                label = { Text(size) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Color", style = MaterialTheme.typography.titleMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        product.availableColors.forEach { color ->
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable { selectedColor = color }
                                    .then(
                                        if (color == selectedColor) {
                                            Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                        } else Modifier
                                    )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Stock disponible: ${product.stock}", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = {
                            onAddToCart(product)
                            scope.launch {
                                showNotification = true
                                delay(2000)
                                showNotification = false
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        enabled = product.stock > 0
                    ) {
                        Text(if (product.stock > 0) "Agregar al Carrito" else "Agotado", fontSize = 16.sp)
                    }
                }
            }
        }
        TopNotification(visible = showNotification, message = "Se ha agregado al carrito")
    }
}


// --- COMPONENTE PARA LA NOTIFICACIÓN SUPERIOR ---
// ... (Sin cambios)
@Composable
fun TopNotification(visible: Boolean, message: String) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(initialOffsetY = { -it }),
        exit = slideOutVertically(targetOffsetY = { -it })
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 50.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(16.dp),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.CheckCircle, contentDescription = "Éxito", tint = MaterialTheme.colorScheme.onSecondaryContainer)
                Spacer(Modifier.width(8.dp))
                Text(message, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Bold)
            }
        }
    }
}


// --- PANTALLA DEL CARRITO ---
// ... (Sin cambios)
@Composable
fun CartScreen(cartItems: List<Product>, onRemoveItem: (Product) -> Unit) {
    Scaffold { innerPadding ->
        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.ShoppingCart, contentDescription = "Carrito vacío", modifier = Modifier.size(80.dp), tint = Color.Gray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Tu carrito está vacío", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                contentPadding = innerPadding,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)) }
                items(cartItems, key = { it.id }) { product ->
                    ProductCartItem(
                        product = product,
                        onRemoveClick = onRemoveItem
                    )
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }
}


// --- PANTALLA DE PERFIL ---
@Composable
fun ProfileScreen(user: User) {
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.background,
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.1f)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))
        Image(
            painter = painterResource(id = user.profileImageRes),
            contentDescription = "Foto de perfil",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .border(4.dp, MaterialTheme.colorScheme.primary, CircleShape)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = user.name,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(24.dp))

        // --- Tarjeta de información de contacto ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                ProfileInfoRow(icon = Icons.Outlined.Email, text = user.email)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                ProfileInfoRow(icon = Icons.Outlined.Phone, text = user.phone)
            }
        }
    }
}

@Composable
fun ProfileInfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = text, style = MaterialTheme.typography.bodyLarge)
    }
}


// --- PREVIEWS ---
// ... (Sin cambios)
@Preview(showBackground = true, name = "Product List Light")
@Composable
fun PreviewProductListScreen() {
    MyApplicationTheme {
        ProductListScreen(
            products = SampleData.products,
            user = CurrentUser.user,
            onProductClick = {}
        )
    }
}

@Preview(showBackground = true, name = "Cart Screen Empty")
@Composable
fun PreviewCartScreen_Empty() {
    MyApplicationTheme {
        CartScreen(cartItems = emptyList(), onRemoveItem = {})
    }
}

@Preview(showBackground = true, name = "Cart Screen With Items")
@Composable
fun PreviewCartScreen_WithItems() {
    MyApplicationTheme {
        CartScreen(cartItems = SampleData.products.take(2), onRemoveItem = {})
    }
}

@Preview(showBackground = true, name = "Product Detail")
@Composable
fun PreviewProductDetailScreen() {
    MyApplicationTheme {
        ProductDetailScreen(
            product = SampleData.products.first(),
            onAddToCart = {},
            onBack = {}
        )
    }
}

@Preview(showBackground = true, name = "Top Notification")
@Composable
fun PreviewTopNotification() {
    MyApplicationTheme {
        TopNotification(visible = true, message = "Este es un mensaje de prueba")
    }
}

@Preview(showBackground = true, name = "Profile Screen")
@Composable
fun PreviewProfileScreen() {
    MyApplicationTheme {
        ProfileScreen(user = CurrentUser.user)
    }
}
