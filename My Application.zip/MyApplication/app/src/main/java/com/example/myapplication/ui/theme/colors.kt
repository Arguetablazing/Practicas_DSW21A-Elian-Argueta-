package com.example.myapplication.ui.theme

// En: app/src/main/java/com/example/myapplication/ui/theme/Color.kt


import androidx.compose.ui.graphics.Color

// Paleta de Colores Morados
val PurplePrimary = Color(0xFF6A1B9A) // Morado principal
val PurpleSecondary = Color(0xFF3124AA) // Morado secundario
val PurpleTertiary = Color(0xFFAB47BC) // Morado más claro

val LightPurpleContainer = Color(0xFFF3E5F5) // Fondo claro para contenedores
val OnLightPurpleContainer = Color(0xFF7106F1) // Texto/íconos sobre el fondo claro

val DarkPurpleContainer = Color(0xFF4A148C) // Fondo oscuro para contenedores
val OnDarkPurpleContainer = Color(0xFFE1BEE7) // Texto/íconos sobre el fondo oscuro
